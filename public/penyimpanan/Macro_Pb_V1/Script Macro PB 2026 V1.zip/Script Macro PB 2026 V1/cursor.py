import tkinter as tk
import ctypes

# ======================
# SETTING
# ======================
CROSSHAIR_SIZE = 14   # panjang garis
THICKNESS = 2         # ketebalan
COLOR = "green"       # warna PB
GAP = 4               # jarak tengah

# ======================
# INIT WINDOW
# ======================
root = tk.Tk()
root.overrideredirect(True)
root.attributes("-topmost", True)
root.attributes("-transparentcolor", "black")

screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()

root.geometry(f"{screen_width}x{screen_height}+0+0")
root.configure(bg="black")

canvas = tk.Canvas(
    root,
    width=screen_width,
    height=screen_height,
    bg="black",
    highlightthickness=0
)
canvas.pack()

cx = screen_width // 2
cy = screen_height // 2

# ======================
# DRAW PB STYLE (+)
# ======================
# Horizontal kiri
canvas.create_line(
    cx - GAP - CROSSHAIR_SIZE, cy,
    cx - GAP, cy,
    fill=COLOR,
    width=THICKNESS
)

# Horizontal kanan
canvas.create_line(
    cx + GAP, cy,
    cx + GAP + CROSSHAIR_SIZE, cy,
    fill=COLOR,
    width=THICKNESS
)

# Vertikal atas
canvas.create_line(
    cx, cy - GAP - CROSSHAIR_SIZE,
    cx, cy - GAP,
    fill=COLOR,
    width=THICKNESS
)

# Vertikal bawah
canvas.create_line(
    cx, cy + GAP,
    cx, cy + GAP + CROSSHAIR_SIZE,
    fill=COLOR,
    width=THICKNESS
)

# ======================
# CLICK THROUGH
# ======================
hwnd = ctypes.windll.user32.GetParent(root.winfo_id())
styles = ctypes.windll.user32.GetWindowLongW(hwnd, -20)
ctypes.windll.user32.SetWindowLongW(
    hwnd,
    -20,
    styles | 0x80000 | 0x20  # WS_EX_LAYERED | WS_EX_TRANSPARENT
)

root.mainloop()
